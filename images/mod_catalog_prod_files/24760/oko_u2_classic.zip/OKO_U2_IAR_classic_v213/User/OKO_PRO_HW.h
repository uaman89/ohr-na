

#ifndef _OKO_PRO_HW_
  #define _OKO_PRO_HW_

  #define OKO_U2

/*  ����� ��� ���������� RX/TX enable RS485  */
  #define RS485_RX_TX_PORT              GPIOB
  #define RS485_RX_TX_PIN               GPIO_Pin_2
  #define RS485_RX_TX_APB_CLOCK         RCC_APB2Periph_GPIOB
  #define DRIVER_485_SEND		{RS485_RX_TX_PORT->BSRR = RS485_RX_TX_PIN;} 
  #define DRIVER_485_RECEIVE		{RS485_RX_TX_PORT->BRR = RS485_RX_TX_PIN;}

/* ����������� �����, �����, ����������, ����������� ����������, DMA ��� ������ � RS485  */
  #define RS485_PORT                    GPIOA
  #define RS485_PIN_RX                  GPIO_Pin_10
  #define RS485_PIN_TX                  GPIO_Pin_9
  #define RS485_APB_PERIPH_UART         RCC_APB2Periph_USART1
  #define RS485_APB_PERIPH_PIN          RCC_APB2Periph_GPIOA
  #define RS485_UART                    USART1
  #define RS485_UART_IRQN               USART1_IRQn
  #define RS485_UART_IRQHANDLER         USART1_IRQHandler
  #define RS485_DMA_RX                  DMA1_Channel5 /* ��������!!! ������� �� �����*/

/* ����������� �����, ����� ��� 1Wire_1 */
  #define _1WIRE_1_PORT_RX              GPIOD
  #define _1WIRE_1_PIN_RX               GPIO_Pin_2
  #define _1WIRE_1_PORT_TX              GPIOC
  #define _1WIRE_1_PIN_TX               GPIO_Pin_12
  #define _1WIRE_1_APB_PERIPH_UART      RCC_APB1Periph_UART5
  #define _1WIRE_1_APB_PERIPH_PIN_RX    RCC_APB2Periph_GPIOD
  #define _1WIRE_1_APB_PERIPH_PIN_TX    RCC_APB2Periph_GPIOC
  #define _1WIRE_1_UART                 UART5

/* ����������� �����, ����� ��� 1Wire_2 */
  #define _1WIRE_2_PORT_RX              GPIOB
  #define _1WIRE_2_PIN_RX               GPIO_Pin_11
  #define _1WIRE_2_PORT_TX              GPIOB
  #define _1WIRE_2_PIN_TX               GPIO_Pin_10
  #define _1WIRE_2_APB_PERIPH_UART      RCC_APB1Periph_USART3
  #define _1WIRE_2_APB_PERIPH_PIN_RX    RCC_APB2Periph_GPIOB
  #define _1WIRE_2_APB_PERIPH_PIN_TX    RCC_APB2Periph_GPIOB
  #define _1WIRE_2_UART                 USART3

/*  ����� MRF_SS ��� ��������� MRF_SLAVE  */
  #define MRF_SS_PORT                   GPIOB
  #define MRF_SS_PIN                    GPIO_Pin_12
  #define MRF_SS_APB_CLOCK              RCC_APB2Periph_GPIOB



/*  ����� ��� ���������/���������� GSM-������ �� ����� "������" (Powerkey)  */
  #define PWRKEY_PORT                   GPIOB
  #define PWRKEY_PIN                    GPIO_Pin_9
  #define PWRKEY_APB_CLOCK              RCC_APB2Periph_GPIOB
  #define PWRKEY_ON                     {PWRKEY_PORT->BSRR = PWRKEY_PIN;}
  #define PWRKEY_OFF                    {PWRKEY_PORT->BRR = PWRKEY_PIN;}

/*  ����� ��� ���������/���������� ������� GSM-������  */
  #define POWER_GSM_PORT                GPIOC
  #define POWER_GSM_PIN                 GPIO_Pin_13
  #define POWER_GSM_APB_CLOCK           RCC_APB2Periph_GPIOC
  #define POWER_GSM_ON                  {POWER_GSM_PORT->BSRR = POWER_GSM_PIN;}
  #define POWER_GSM_OFF                 {POWER_GSM_PORT->BRR = POWER_GSM_PIN;}

/*  ���� ��� ������� ������� RING �� GSM-������  */
  #define SIM900_RING_PORT              GPIOB
  #define SIM900_RING_PIN               GPIO_Pin_8
  #define SIM900_RING_APB_CLOCK         RCC_APB2Periph_GPIOB
  #define SIM900_RING_STATE             GPIO_ReadInputDataBit(SIM900_RING_PORT, SIM900_RING_PIN)


/* ����������� �����, �����, ����������, ����������� ����������, DMA ��� ������ � SIM900  */
  #define SIM900_PORT                   GPIOA
  #define SIM900_PIN_RX                 GPIO_Pin_3
  #define SIM900_PIN_TX                 GPIO_Pin_2
  #define SIM900_APB_PERIPH_UART        RCC_APB1Periph_USART2
  #define SIM900_APB_PERIPH_PIN         RCC_APB2Periph_GPIOA
  #define SIM900_UART                   USART2
  #define SIM900_UART_BAUD              9600        
  #define SIM900_UART_IRQN              USART2_IRQn
  #define SIM900_UART_IRQHANDLER        USART2_IRQHandler
  #define SIM900_DMA_RX                 DMA1_Channel6 /* ��������!!! ������� �� �����*/

/*  ����� �� ������  */
  #define SIRENA_PORT                   GPIOB
  #define SIRENA_PIN                    GPIO_Pin_7
  #define SIRENA_APB_CLOCK              RCC_APB2Periph_GPIOB
  #define SIRENA_ON                     {SIRENA_PORT->BSRR = SIRENA_PIN;} 
  #define SIRENA_OFF                    {SIRENA_PORT->BRR = SIRENA_PIN;}
  #define SIRENA_STATE                  GPIO_ReadInputDataBit(SIRENA_PORT, SIRENA_PIN)


/*  ����� �� ���������  */
  #define LED_PORT                      GPIOB
  #define LED_PIN                       GPIO_Pin_6
  #define LED_APB_CLOCK                 RCC_APB2Periph_GPIOB
  #define LED_ON                        {LED_PORT->BSRR = LED_PIN;}
  #define LED_OFF                       {LED_PORT->BRR = LED_PIN;}
  #define LED_STATE                     GPIO_ReadInputDataBit(LED_PORT, LED_PIN)

/*  ����� 1 */
  #define OUT1_PORT                     GPIOB
  #define OUT1_PIN                      GPIO_Pin_5
  #define OUT1_APB_CLOCK                RCC_APB2Periph_GPIOB
  #define OUT1_ON                       {Set_Out_Pulse(OUTPUT_1); OUT1_PORT->BSRR = OUT1_PIN;}
  #define OUT1_OFF                      {Clear_Out_Pulse(OUTPUT_1); OUT1_PORT->BRR = OUT1_PIN;}
  #define OUT1_STATE                    GPIO_ReadInputDataBit(OUT1_PORT, OUT1_PIN)

/*  ����� 2 */
  #define OUT2_PORT                     GPIOB
  #define OUT2_PIN                      GPIO_Pin_4
  #define OUT2_APB_CLOCK                RCC_APB2Periph_GPIOB
  #define OUT2_ON                       {Set_Out_Pulse(OUTPUT_2); OUT2_PORT->BSRR = OUT2_PIN;}
  #define OUT2_OFF                      {Clear_Out_Pulse(OUTPUT_2); OUT2_PORT->BRR = OUT2_PIN;}
  #define OUT2_STATE                    GPIO_ReadInputDataBit(OUT2_PORT, OUT2_PIN)

/*  ����� 3 */
  #define OUT3_PORT                     GPIOB
  #define OUT3_PIN                      GPIO_Pin_3
  #define OUT3_APB_CLOCK                RCC_APB2Periph_GPIOB
  #define OUT3_ON                       {Set_Out_Pulse(OUTPUT_3); OUT3_PORT->BSRR = OUT3_PIN;}
  #define OUT3_OFF                      {Clear_Out_Pulse(OUTPUT_3); OUT3_PORT->BRR = OUT3_PIN;}
  #define OUT3_STATE                    GPIO_ReadInputDataBit(OUT3_PORT, OUT3_PIN)

/*  ����� 4 */
  #define OUT4_PORT                     GPIOC
  #define OUT4_PIN                      GPIO_Pin_11
  #define OUT4_APB_CLOCK                RCC_APB2Periph_GPIOC
  #define OUT4_ON                       {Set_Out_Pulse(OUTPUT_4); OUT4_PORT->BSRR = OUT4_PIN;}
  #define OUT4_OFF                      {Clear_Out_Pulse(OUTPUT_4); OUT4_PORT->BRR = OUT4_PIN;}
  #define OUT4_STATE                    GPIO_ReadInputDataBit(OUT4_PORT, OUT4_PIN)

/*  ����� 5 */
  #define OUT5_PORT                     GPIOC
  #define OUT5_PIN                      GPIO_Pin_10
  #define OUT5_APB_CLOCK                RCC_APB2Periph_GPIOC
  #define OUT5_ON                       {Set_Out_Pulse(OUTPUT_5); OUT5_PORT->BSRR = OUT5_PIN;}
  #define OUT5_OFF                      {Clear_Out_Pulse(OUTPUT_5); OUT5_PORT->BRR = OUT5_PIN;}
  #define OUT5_STATE                    GPIO_ReadInputDataBit(OUT5_PORT, OUT5_PIN)

/*  ����� 6 */
  #define OUT6_PORT                     GPIOA
  #define OUT6_PIN                      GPIO_Pin_15
  #define OUT6_APB_CLOCK                RCC_APB2Periph_GPIOA
  #define OUT6_ON                       {Set_Out_Pulse(OUTPUT_6); OUT6_PORT->BSRR = OUT6_PIN;}
  #define OUT6_OFF                      {Clear_Out_Pulse(OUTPUT_6); OUT6_PORT->BRR = OUT6_PIN;}
  #define OUT6_STATE                    GPIO_ReadInputDataBit(OUT6_PORT, OUT6_PIN)

/*  ����� 7 */
  #define OUT7_PORT                     GPIOC
  #define OUT7_PIN                      GPIO_Pin_7
  #define OUT7_APB_CLOCK                RCC_APB2Periph_GPIOC
  #define OUT7_ON                       {Set_Out_Pulse(OUTPUT_7); OUT7_PORT->BSRR = OUT7_PIN;}
  #define OUT7_OFF                      {Clear_Out_Pulse(OUTPUT_7); OUT7_PORT->BRR = OUT7_PIN;}
  #define OUT7_STATE                    GPIO_ReadInputDataBit(OUT7_PORT, OUT7_PIN)

/*  ����� 8 */
  #define OUT8_PORT                     GPIOA
  #define OUT8_PIN                      GPIO_Pin_8
  #define OUT8_APB_CLOCK                RCC_APB2Periph_GPIOA
  #define OUT8_ON                       {Set_Out_Pulse(OUTPUT_8); OUT8_PORT->BSRR = OUT8_PIN;}
  #define OUT8_OFF                      {Clear_Out_Pulse(OUTPUT_8); OUT8_PORT->BRR = OUT8_PIN;}
  #define OUT8_STATE                    GPIO_ReadInputDataBit(OUT8_PORT, OUT8_PIN)


/*  ���� ��� ������� ��������� ������ �� ����� */
  #define BUTTON_PORT                   GPIOA
  #define BUTTON_PIN                    GPIO_Pin_0
  #define BUTTON_APB_CLOCK              RCC_APB2Periph_GPIOA
  #define BUTTON_STATE                  GPIO_ReadInputDataBit(BUTTON_PORT, BUTTON_PIN)


/*  ���� 1 */
  #define IN1_PORT                      GPIOC
  #define IN1_PIN                       GPIO_Pin_2
  #define IN1_APB_CLOCK                 RCC_APB2Periph_GPIOC
  #define IN1_STATE                     Read_Input(IN1_PORT, IN1_PIN, INPUT_1)

/*  ���� 2 */
  #define IN2_PORT                      GPIOC
  #define IN2_PIN                       GPIO_Pin_1
  #define IN2_APB_CLOCK                 RCC_APB2Periph_GPIOC
  #define IN2_STATE                     Read_Input(IN2_PORT, IN2_PIN, INPUT_2)

/*  ���� 3 */
  #define IN3_PORT                      GPIOC
  #define IN3_PIN                       GPIO_Pin_0
  #define IN3_APB_CLOCK                 RCC_APB2Periph_GPIOC
  #define IN3_STATE                     Read_Input(IN3_PORT, IN3_PIN, INPUT_3)

/*  ���� 4 */
  #define IN4_PORT                      GPIOA
  #define IN4_PIN                       GPIO_Pin_1
  #define IN4_APB_CLOCK                 RCC_APB2Periph_GPIOA
  #define IN4_STATE                     Read_Input(IN4_PORT, IN4_PIN, INPUT_4)

/*  ���� 5 */
  #define IN5_PORT                      GPIOA
  #define IN5_PIN                       GPIO_Pin_5
  #define IN5_APB_CLOCK                 RCC_APB2Periph_GPIOA
  #define IN5_STATE                     Read_Input(IN5_PORT, IN5_PIN, INPUT_5)

/*  ���� 6 */
  #define IN6_PORT                      GPIOC
  #define IN6_PIN                       GPIO_Pin_3
  #define IN6_APB_CLOCK                 RCC_APB2Periph_GPIOC
  #define IN6_STATE                     Read_Input(IN6_PORT, IN6_PIN, INPUT_6)

/*  ���� 7 */
  #define IN7_PORT                      GPIOA
  #define IN7_PIN                       GPIO_Pin_6
  #define IN7_APB_CLOCK                 RCC_APB2Periph_GPIOA
  #define IN7_STATE                     Read_Input(IN7_PORT, IN7_PIN, INPUT_7)

/*  ���� 8 */
  #define IN8_PORT                      GPIOA
  #define IN8_PIN                       GPIO_Pin_7
  #define IN8_APB_CLOCK                 RCC_APB2Periph_GPIOA
  #define IN8_STATE                     Read_Input(IN8_PORT, IN8_PIN, INPUT_8)

/*  ���� ARM */
  #define ARM_PORT                      _1WIRE_1_PORT_RX
  #define ARM_PIN                       _1WIRE_1_PIN_RX
  #define ARM_APB_CLOCK                 _1WIRE_1_APB_PERIPH_PIN_RX
  #define ARM_STATE                     GPIO_ReadInputDataBit(ARM_PORT,ARM_PIN)

/*  ���������� ���� AIN_1 */
//  #define AIN_1_PORT GPIOA
//  #define AIN_1_PIN  GPIO_Pin_4
//  #define AIN_1_APB_CLOCK  RCC_APB2Periph_GPIOA

/*  ���������� ���� AIN_2 */
//  #define AIN_2_PORT GPIOC
//  #define AIN_2_PIN  GPIO_Pin_4
//  #define AIN_2_APB_CLOCK  RCC_APB2Periph_GPIOC

/*  ���������� ���� AIN_3 */
//  #define AIN_3_PORT GPIOC
//  #define AIN_3_PIN  GPIO_Pin_5
//  #define AIN_3_APB_CLOCK  RCC_APB2Periph_GPIOC

/* ��� ���������� ���������� ����� �������  */
//    #define WD_DISABLE
//    #define RS485_BLOCKED
//    #define _1WIRE_1_BLOCKED
//    #define _1WIRE_2_BLOCKED
//    #define SPI_BLOCKED
//    #define ADC_BLOCKED
    #define RTC_BLOCKED



#endif