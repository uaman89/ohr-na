#ifndef _INPUT_DATA_FROM_USB_
  #define _INPUT_DATA_FROM_USB_
  
  #define MAX_COUNT_MSG_IN_SERIAL_QUEUE	1
  #define SERIAL_MAX_RX_DATA_LEN	249
  #define SERIAL_MAX_DATA_LEN	        255

  #define PACK_HEADER 0xF1
  #define FESC        0xF2
  #define TFBGN       0xF3
  #define TFESC       0xF4

  #define BRODCASTING_TYPE_1    0xBF
  #define BRODCASTING_TYPE_2    0xFF

  #define SERIAL_NUMBER_TYPE_1  0x3F
  #define SERIAL_NUMBER_TYPE_2  0x7F

  typedef struct 
  {
   struct pt pt_parser;
   u8 *p_data;
   u8 NumberPrevious;
   u8 Header;
   u8 Addr;
   u8 NumberPresent;
   u8 Code;
   u8 Size;
   u8 *pData;
   u8 CRC_[2];
  }TypeDef_InputPackage;

  typedef struct 
  {
   u8 *AllocatedMemory;
   u8 Command;
   u8 *pData;
   u16 Size;
  }TypeDef_Data;

  PT_THREAD(protothread(u8 *pData, u16 *pDataLenght,  TypeDef_InputPackage *Package));
  void FillingIncomingDataStruct(TypeDef_InputPackage *Input_Package, TypeDef_Data *Input_Data);

#endif