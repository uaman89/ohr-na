
#ifndef _MAIN_
  #define _MAIN_

/* ���������� ����� */
#define TASK_CORE_IDLE_PRIORITY			( tskIDLE_PRIORITY + 2 )
#define TASK_I_O_TIMERS_PRIORITY           	( tskIDLE_PRIORITY + 2 )
#define TASK_ADC_PRIORITY			( tskIDLE_PRIORITY + 2 )
#define TASK_1WIRE_1_PRIORITY			( tskIDLE_PRIORITY + 2 )
#define TASK_1WIRE_2_PRIORITY			( tskIDLE_PRIORITY + 2 )
#define TASK_SPI_PRIORITY                       ( tskIDLE_PRIORITY + 2 )
#define TASK_RS485_PRIORITY                     ( tskIDLE_PRIORITY + 2 )
#define TASK_GSM_PRIORITY			( tskIDLE_PRIORITY + 2 )
#define TASK_PRINT_DEBUG_PRIORITY		( tskIDLE_PRIORITY + 2 )

/* ������ ����� ��� �����*/
//5E normal level of HWM
#define TASK_CORE_IDLE_STACK_SIZE	        ( configMINIMAL_STACK_SIZE + 6 )
#define TASK_I_O_TIMERS_STACK_SIZE	        ( configMINIMAL_STACK_SIZE + 10 )
#define TASK_ADC_STACK_SIZE	                ( configMINIMAL_STACK_SIZE + 6 )
#define TASK_1WIRE_1_STACK_SIZE	                ( configMINIMAL_STACK_SIZE + 17 )
#define TASK_1WIRE_2_STACK_SIZE	                ( configMINIMAL_STACK_SIZE + 45 )
#define TASK_SPI_STACK_SIZE	                ( configMINIMAL_STACK_SIZE + 17 )
#define TASK_RS485_STACK_SIZE	                ( configMINIMAL_STACK_SIZE + 20 )
#define TASK_GSM_STACK_SIZE	                ( configMINIMAL_STACK_SIZE + 54 )
#define TASK_PRINT_DEBUG_STACK_SIZE	        ( configMINIMAL_STACK_SIZE + 26 )

  void USB_Config();
  void InPins_Config();
  void OutPins_Config();
  void RTC_Config(void);
  void RTC_IRQHandler(void);
  void PreInit(void);
  void Hardware_Init(void); 
  void WatchDog_Init(void);
  
#endif