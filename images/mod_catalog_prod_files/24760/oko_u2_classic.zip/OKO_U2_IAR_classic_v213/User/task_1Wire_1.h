
#ifndef _TASK_1WIRE_
  #define _TASK_1WIRE_

  #define USART_RECEIVE_DATA_1WIRE_1     (uint8_t)(_1WIRE_1_UART->DR)
  #define IBUTTON_DATA_LEN               10  
  #define IBUTTON_DATA_READ              USART_RECEIVE_DATA_1WIRE_1;

  void _1Wire_1_UART_config(void);
  void _1Wire_1_PinConfig(void);
  char _1Wire_1_Reset(void);
  char Check_IButton (char * Sensor_Data);
  char Save_IButton (char * Sensor_Data);
  char _1W_CRC(char *mas, char Len );
  void Task_1WIRE_1(void *pvParameters );
  u8 _1Wire_1_ByteWrite( u8 ucByte);
  void _1Wire_1_Config (void);
  void USART_SendData_1WIRE_1(u8 Data);
  void USART_ClearFlag_1WIRE_1(uint16_t USART_FLAG);
  FlagStatus USART_GetFlagStatus_1WIRE_1(uint16_t USART_FLAG);
  void USART_Init_1W1(USART_TypeDef* USARTx, USART_InitTypeDef* USART_InitStruct);
  void Arm_1Wire(char arm_group);

  
  
#endif
  
