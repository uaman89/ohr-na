
#ifndef _TASK_CORE_IDLE_
  #define _TASK_CORE_IDLE_

  void Task_CORE_IDLE( void *pvParameters );
  
#endif