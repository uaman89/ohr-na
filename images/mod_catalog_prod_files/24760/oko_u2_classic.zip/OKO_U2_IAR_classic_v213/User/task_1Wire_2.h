
#ifndef _TASK_1WIRE_2_
  #define _TASK_1WIRE_2_


  #define USART_RECEIVE_DATA_1WIRE_2     (uint8_t)(_1WIRE_2_UART->DR)
  #define T_DATA_LEN                     20  
  #define T_DATA_READ                    USART_RECEIVE_DATA_1WIRE_2;

  void _1Wire_2_UART_config(void);
  void _1Wire_2_PinConfig(void);
  char _1Wire_2_Reset(void);
  char Check_DS1820 (char * Sensor_Data);
  char Save_DS1820 (char * Sensor_Data);
  char Send_Sensor_ROM_Code (char cur_sensor, char * Sensor_data);
  void Task_1WIRE_2(void *pvParameters );
  u8 _1Wire_2_ByteWrite( u8 ucByte);
  void _1Wire_2_Config (void);
  void USART_SendData_1WIRE_2(u8 Data);
  void USART_ClearFlag_1WIRE_2(uint16_t USART_FLAG);
  FlagStatus USART_GetFlagStatus_1WIRE_2(uint16_t USART_FLAG); 
  void USART_Init_1W2(USART_TypeDef* USARTx, USART_InitTypeDef* USART_InitStruct);
  


  
  
#endif