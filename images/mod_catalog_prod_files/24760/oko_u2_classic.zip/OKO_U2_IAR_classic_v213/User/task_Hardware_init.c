
#include "libraries.h"

/*******************************************************************************
* Function Name  : Task_HARDWARE_INIT
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/ 

void Task_HARDWARE_INIT (void *pvParameters) 
{
  /* ������ ������ ���� ��������� ����������� ��� ����������� ����. */
  while (1)
  { 
  
    USBInit();
    InPinsConfig();
    OutPinsConfig();
    SIM900_Config();
    RS485_config();
    _1Wire_1_config();
    _1Wire_2_config();
    SPI_config();
    Setup_ADC1();
    RTC_Configuration();
    
    
 /*  ����� ������������� ��������� ��������� ��� ������ �� ������*/ 
    vTaskDelete( NULL ); 
  }
  
  /* ��� ������ ���� ����������� ���, ����� � ������ ������ (break) �� ����������
       ���� ������������ ����� ������, ������ ������ ���� ������� ������ ���
       ���������� ��������� ����� ���� �������. �������� NULL, ����������
       vTaskDelete(), ����������, ��� ������ ���� ������� ��������� (���, �������
       ��������) ������. 
    �����!!!
    ����� ������� vTaskDelete ����������, � ����� 
    FreeRTOSConfig.h ����� ���������� � 1 INCLUDE_vTaskDelete.
  
  */
    
//    vTaskDelete( NULL ); 
}

/*******************************************************************************
* Function Name  : USBInit
* Description    : 
* Input          : 
* Output         : 
* Return         : 
*******************************************************************************/
void USBInit() 
{ 
	Set_System();
	Set_USBClock();
	USB_Interrupts_Config();
	USB_Init();
}


/*******************************************************************************
* Function Name  : 
* Description    : 
* Input          : 
* Output         : 
* Return         : 
*******************************************************************************/
void OutPinsConfig()
{
  
  GPIO_InitTypeDef GPIO_InitStructure;
  

  RCC_APB2PeriphClockCmd(LED_APB_CLOCK , ENABLE);
  GPIO_InitStructure.GPIO_Pin = LED_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init( LED_PORT , &GPIO_InitStructure);
  
    
  RCC_APB2PeriphClockCmd(SIRENA_APB_CLOCK, ENABLE);  
  GPIO_InitStructure.GPIO_Pin = SIRENA_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(SIRENA_PORT, &GPIO_InitStructure); 
 
  RCC_APB2PeriphClockCmd(OUT1_APB_CLOCK, ENABLE);  
  GPIO_InitStructure.GPIO_Pin = OUT1_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(OUT1_PORT, &GPIO_InitStructure);
 
  RCC_APB2PeriphClockCmd(OUT2_APB_CLOCK, ENABLE);  
  GPIO_InitStructure.GPIO_Pin = OUT2_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(OUT2_PORT, &GPIO_InitStructure);
 
  
  RCC_APB2PeriphClockCmd(OUT3_APB_CLOCK, ENABLE);  
  GPIO_InitStructure.GPIO_Pin = OUT3_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(OUT3_PORT, &GPIO_InitStructure);
 
  RCC_APB2PeriphClockCmd(OUT4_APB_CLOCK, ENABLE);  
  GPIO_InitStructure.GPIO_Pin = OUT4_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(OUT4_PORT, &GPIO_InitStructure);
 
  RCC_APB2PeriphClockCmd(OUT5_APB_CLOCK, ENABLE);  
  GPIO_InitStructure.GPIO_Pin = OUT5_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(OUT5_PORT, &GPIO_InitStructure);
   
  RCC_APB2PeriphClockCmd(OUT6_APB_CLOCK, ENABLE);  
  GPIO_InitStructure.GPIO_Pin = OUT6_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(OUT6_PORT, &GPIO_InitStructure);
   
  RCC_APB2PeriphClockCmd(OUT7_APB_CLOCK, ENABLE);  
  GPIO_InitStructure.GPIO_Pin = OUT7_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(OUT7_PORT, &GPIO_InitStructure);
 
  RCC_APB2PeriphClockCmd(OUT8_APB_CLOCK, ENABLE);  
  GPIO_InitStructure.GPIO_Pin = OUT8_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(OUT8_PORT, &GPIO_InitStructure);
  
  
}
/*******************************************************************************
* Function Name  : 
* Description    : 
* Input          : 
* Output         : 
* Return         : 
*******************************************************************************/
void InPinsConfig()
{
  GPIO_InitTypeDef GPIO_InitStructure;
  
  RCC_APB2PeriphClockCmd(IN1_APB_CLOCK, ENABLE);
  GPIO_InitStructure.GPIO_Pin = IN1_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(IN1_PORT, &GPIO_InitStructure);

  RCC_APB2PeriphClockCmd(IN2_APB_CLOCK, ENABLE);
  GPIO_InitStructure.GPIO_Pin = IN2_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(IN2_PORT, &GPIO_InitStructure);
  
  RCC_APB2PeriphClockCmd(IN3_APB_CLOCK, ENABLE);
  GPIO_InitStructure.GPIO_Pin = IN3_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(IN3_PORT, &GPIO_InitStructure);
 
  RCC_APB2PeriphClockCmd(IN4_APB_CLOCK, ENABLE);
  GPIO_InitStructure.GPIO_Pin = IN4_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(IN4_PORT, &GPIO_InitStructure);
 
  RCC_APB2PeriphClockCmd(IN5_APB_CLOCK, ENABLE);
  GPIO_InitStructure.GPIO_Pin = IN5_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(IN5_PORT, &GPIO_InitStructure);
 
  RCC_APB2PeriphClockCmd(IN6_APB_CLOCK, ENABLE);
  GPIO_InitStructure.GPIO_Pin = IN6_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(IN6_PORT, &GPIO_InitStructure);
  
  RCC_APB2PeriphClockCmd(IN7_APB_CLOCK, ENABLE);
  GPIO_InitStructure.GPIO_Pin = IN7_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(IN7_PORT, &GPIO_InitStructure);

  RCC_APB2PeriphClockCmd(IN8_APB_CLOCK, ENABLE);
  GPIO_InitStructure.GPIO_Pin = IN8_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(IN8_PORT, &GPIO_InitStructure);
 
  RCC_APB2PeriphClockCmd(BUTTON_APB_CLOCK, ENABLE);
  GPIO_InitStructure.GPIO_Pin = BUTTON_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(BUTTON_PORT, &GPIO_InitStructure);
 
  
}


/*******************************************************************************
* Function Name  : USB_LP_CAN1_RX0_IRQHandler
* Description    : 
* Input          : 
* Output         : 
* Return         : 
*******************************************************************************/
void USB_LP_CAN1_RX0_IRQHandler(void)
{
  USB_Istr();
}

/*******************************************************************************
* Function Name  : RTC_Configuration
* Description    : Configures the RTC
* Input          : 
* Output         : 
* Return         : 
*******************************************************************************/
void RTC_Configuration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;
    /* Enable the RTC Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = RTC_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);  
  
    /* Enable PWR and BKP clocks */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);

    /* Allow access to BKP Domain */
    PWR_BackupAccessCmd(ENABLE);

    
    /* Reset Backup Domain */
    RCC_BackupResetCmd(ENABLE);
    RCC_BackupResetCmd(DISABLE);

    /* Enable LSE */
    RCC_LSEConfig(RCC_LSE_ON);
    /* Wait till LSE is ready */
    while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET)
    {}

    /* Select LSE as RTC Clock Source */
    RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);

    /* Enable RTC Clock */
    RCC_RTCCLKCmd(ENABLE);

    /* Wait for RTC registers synchronization */
    RTC_WaitForSynchro();

    /* Wait until last write operation on RTC registers has finished */
    RTC_WaitForLastTask();

    /* Enable the RTC Second */
    RTC_ITConfig(RTC_IT_SEC, ENABLE);

    /* Wait until last write operation on RTC registers has finished */
    RTC_WaitForLastTask();

    /* Set RTC prescaler: set RTC period to 1sec */
    RTC_SetPrescaler(32767); /* RTC period = RTCCLK/RTC_PR = (32.768 KHz)/(32767+1) */

    /* Wait until last write operation on RTC registers has finished */
    RTC_WaitForLastTask();
}


/*******************************************************************************
* Function Name  : RTC_IRQHandler
* Description    : This function handles RTC global interrupt request
* Input          : 
* Output         : 
* Return         : 
*******************************************************************************/
void RTC_IRQHandler(void)
{
    if (RTC_GetITStatus(RTC_IT_SEC) != RESET)
    {
      /* Clear the RTC Second interrupt */
      RTC_ClearITPendingBit(RTC_IT_SEC);

        /* Toggle LED 
      if (LED_STATE!= RESET) 
      {
         LED_OFF; 
      }
      else
      {
         LED_ON; 
      } 
      */

        /* Wait until last write operation on RTC registers has finished */
        RTC_WaitForLastTask();
    }
}
