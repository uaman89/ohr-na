
#ifndef _COMMAND_1WIRE_
  #define _COMMAND_1WIRE_


/* ����������� ������ ��� 1Wire */
//_1Wire_FUNCTION_COMMANDS
#define _1Wire_CONVERT                 0x44
#define _1Wire_WRITE_SCRATCHPAD        0x4E

#define _1Wire_READ_SCRATCHPAD         0xBE
#define _1Wire_COPY_SCRATCHPAD         0x48

#define _1Wire_RECALL                  0xB8
#define _1Wire_READ_POWER_SUPPLY       0xB4

//_1Wire_ROM ROM COMMANDS
#define _1Wire_SEARCH                  0xF0
#define _1Wire_READ                    0x33
#define _1Wire_READ_DS1990             0x0F

#define _1Wire_MATCH                   0x55
#define _1Wire_SKIP                    0xCC

#define _1Wire_ALARM_SEARCH            0xEC
//_1Wire_Family number
#define _1Wire_DS18B20_FAMILY_NUM      0x28
#define _1Wire_DS18S20_FAMILY_NUM      0x10
#define _1Wire_DS1990A_FAMILY_NUM      0x01

#define _1Wire_READ_BYTE               0xFF

  
#endif
  
