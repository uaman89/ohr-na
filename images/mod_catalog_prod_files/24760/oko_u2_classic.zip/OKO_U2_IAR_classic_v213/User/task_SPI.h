
#ifndef _TASK_SPI_
  #define _TASK_SPI_
  #define RF_PRO_SPI                    SPI2
  #define MRF_SELECT_OFF                {MRF_SS_PORT->BSRR = MRF_SS_PIN;} 
  //#define MRF_SELECT_ON                 {MRF_SS_PORT->BRR = MRF_SS_PIN;}
  
  #define RF_TIMEOUT_LEN                180
  #define SPI_RECEIVE_DATA_RF_PRO      (uint8_t)(SPI2->DR)

u8 SPI_Read(void);
u8 SPI_Write(u8 spidata);
char Check_Sensor (char * Sensor_Data, char length);
char Save_Sensor (char * Sensor_Data);
void Do_RF_Sensor_Alarm (char sensor, TypeDef_EVENT event_alarm);
void SPI_Config(void);
void Task_SPI( void *pvParameters );

#endif