

#ifndef _LIBRARY_
  #define _LIBRARY_

  #include <string.h>

  #include "stm32f10x.h"
  #include "stm32f10x_conf.h"
//  #include "stm32f10x_rtc.h"
//  #include "stm32f10x_pwr.h"
//  #include "stm32f10x_rcc.h"
//  #include "stm32f10x_dma.h"
//  #include "stm32f10x_flash.h"

  #include "FreeRTOS.h"
  #include "task.h"
  #include "queue.h"
  #include "semphr.h"

  #include "usb_lib.h"
  #include "usb_desc.h"
  #include "hw_config.h"
  #include "usb_pwr.h"
  #include "usb_istr.h"
  
  #include "main.h"
  #include "Global.h"
  #include "eeprom.h"
  #include "OKO_PRO_HW.h"
  #include "Command_1Wire.h"
  #include "User_Types.h"
  #include "task_GSM.h"
  #include "task_ADC.h"
  #include "task_CORE_IDLE.h"
  #include "task_I_O_Timers.h"
  #include "task_1Wire_1.h"
  #include "task_1Wire_2.h"
  #include "task_SPI.h"
  #include "task_RS485.h"
  #include "task_PRINT_DEBUG.h"

#endif